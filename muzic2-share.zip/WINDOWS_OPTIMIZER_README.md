# 🖥️ Windows DB Optimizer

## Описание
Общий скрипт для подтягивания всех баз данных для Windows с оптимизацией скорости загрузки.

## Файлы

### 1. `windows_db_optimizer.php`
**PHP скрипт для сервера** - получает все данные одним запросом:
- Треки (20 случайных)
- Альбомы (15 случайных) 
- Артисты (15 случайных)
- Пользователь (если авторизован)
- Лайки треков и альбомов
- Плейлисты
- Статистика

### 2. `windows_db_optimizer.js`
**JavaScript класс для фронтенда** - кэширует данные и предоставляет удобный API:
- `getAllData()` - получить все данные
- `getTracks()` - только треки
- `getAlbums()` - только альбомы
- `getArtists()` - только артисты
- `getUser()` - информация о пользователе
- `getLikes()` - лайки
- `getPlaylists()` - плейлисты
- `benchmark()` - тест производительности

### 3. `test_windows_optimizer.html`
**Тестовая страница** для проверки работы оптимизатора.

## Использование

### В PHP:
```php
// Получить все данные одним запросом
$response = file_get_contents('http://localhost:8888/muzic2/windows_db_optimizer.php');
$data = json_decode($response, true);

echo "Треков: " . count($data['tracks']);
echo "Время загрузки: " . $data['load_time_ms'] . "ms";
```

### В JavaScript:
```javascript
// Загрузить все данные
const data = await window.windowsDBOptimizer.getAllData();
console.log('Треков:', data.tracks.length);
console.log('Время загрузки:', data.load_time_ms + 'ms');

// Или получить только нужные данные
const tracks = await window.windowsDBOptimizer.getTracks();
const albums = await window.windowsDBOptimizer.getAlbums();
```

## Тестирование

1. Откройте: `http://localhost:8888/muzic2/test_windows_optimizer.html`
2. Нажмите "Загрузить все данные"
3. Проверьте время загрузки
4. Запустите бенчмарк для детального анализа

## Оптимизации

### Для Windows:
- ✅ Убраны сложные GROUP BY запросы
- ✅ Убраны JOIN с таблицей artists
- ✅ Минимальные данные в SELECT
- ✅ Один запрос вместо множества
- ✅ Кэширование на фронтенде

### Результат:
- 🚀 Быстрая загрузка всех данных
- 📦 Кэширование для повторных запросов
- 🔄 Автоматическое обновление кэша
- 📊 Детальная статистика производительности

## Интеграция в основной сайт

Замените множественные API вызовы на один:

```javascript
// Вместо:
const userRes = await fetch('/muzic2/src/api/user.php');
const homeRes = await fetch('/muzic2/public/src/api/home.php');
const likesRes = await fetch('/muzic2/src/api/likes.php');

// Используйте:
const data = await window.windowsDBOptimizer.getAllData();
```

Это значительно ускорит загрузку главной страницы на Windows!
