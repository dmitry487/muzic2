# Быстрый старт - Перенос Muzic2

## 🚀 Самый простой способ переноса

### На исходном устройстве (через GitHub):
```bash
cd /Applications/MAMP/htdocs/muzic2
git add .
git commit -m "update"
git push

# Экспорт БД-данных в JSON и добавление в репозиторий
/Applications/MAMP/bin/php/*/bin/php scripts/quick_migrate.php export
mv muzic2_export_*.json data/changes/latest.json
git add data/changes/latest.json
git commit -m "data: seed update"
git push
```

### На новом устройстве (через GitHub):
1. Установите MAMP и Git LFS (`brew install git git-lfs && git lfs install`)
2. Клонируйте репозиторий в `/Applications/MAMP/htdocs/`
3. Скачайте LFS-файлы: `git lfs pull`
4. Запустите:
```bash
cd /Applications/MAMP/htdocs/muzic2
/Applications/MAMP/bin/php/*/bin/php scripts/setup_db.php
/Applications/MAMP/bin/php/*/bin/php scripts/quick_migrate.php import data/changes/latest.json
/Applications/MAMP/bin/php/*/bin/php scripts/quick_migrate.php check
```

## 📁 Что нужно скопировать

### Обязательно:
- Код проекта тянется из GitHub
- Медиа — тянутся через Git LFS (git lfs pull)

### Не нужно:
- Временные файлы, локальные экспорты вне `data/changes/latest.json`

## ⚡ Автоматическая синхронизация

### Для постоянной синхронизации между устройствами:

1. **Настройте общую базу данных** (рекомендуется):
   - Создайте MySQL на VPS/хостинге
   - Обновите `src/config/db.php` на всех устройствах
   - Все изменения будут видны сразу

2. **Или используйте скрипты синхронизации**:
   ```bash
   # Экспорт изменений
   php scripts/export_changes.php --since="2024-01-01"
   
   # Импорт на другом устройстве
   php scripts/import_changes.php --file="changes_export.json"
   
   # Синхронизация медиа
   ./scripts/sync_media.sh /path/to/source user@server:/path/to/dest
   ```

## 🔧 Проверка работоспособности

После переноса проверьте:
1. http://localhost:8888/muzic2/public/ - главная страница
2. Воспроизведение треков
3. Видео режим
4. Поиск
5. Админ-панель: http://localhost:8888/muzic2/public/admin/

## ❗ Важные моменты

- **Права доступа**: `chmod -R 755 muzic2/` и `chmod -R 777 tracks/`
- **Кодировка**: Убедитесь, что БД использует UTF-8
- **Порты MAMP**: Проверьте настройки в `src/config/db.php`
- **Медиа файлы**: Должны быть в папке `tracks/` с правильными путями

## 🆘 Если что-то не работает

1. Проверьте логи: `public/admin/admin_api.log`
2. Запустите проверку: `php scripts/quick_migrate.php check`
3. Проверьте права доступа к файлам
4. Убедитесь, что MAMP запущен и MySQL работает

## 📞 Поддержка

Подробная инструкция: `MIGRATION_GUIDE.md`
