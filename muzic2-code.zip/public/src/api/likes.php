<?php
// Public wrapper to route through web root
require_once __DIR__ . '/../../../src/api/likes.php';
?>


